import pygame
import tower
panel = pygame.Surface((300, 300));
panel.fill('white')

# class tower_panel:
#     def __init__(self, loc = )